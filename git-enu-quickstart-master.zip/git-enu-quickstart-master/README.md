# git
Getting to grips with Git for Edinburgh Napier students


* Getting Started with Git [PDF](https://www.dropbox.com/s/2kz34u0zb4qajvd/getting.started.pdf?dl=1)
