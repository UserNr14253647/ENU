# Programmers' Aptitude Test

This week we shall take a look at the [programmers aptitude test](http://www.kent.ac.uk/careers/tests/computer-test.htm) from the Univerity of Kent Careers department. The test takes around 40 minutes to complete and involves a whole series of questions that are oriented towards the kinds of problems that you *might* see in a programming career.
