# Reviewing

This week we shall reflect on the paper we read previously and, in pairs, write a short critical review and response to the paper we read previously.


