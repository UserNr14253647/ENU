# Critical Reading

This week we shall critically read a paper from the academic/research literature on Computer Science. 

The paper we will read is this [http://dump.mntmn.com/interim-paper/](http://dump.mntmn.com/interim-paper/) which talks about this project [http://interim.mntmn.com/](http://interim.mntmn.com/) and the software, although still in development, can be run on raspberry pi 2 ).

Have a read of the paper and write a review of it, place the review on your blogs (you should all have a blog by now). Your review might want to mention why Interim has been created, summarise the features of the operating system and also give your opinions on aspects such as the clarity of the paper and whether you think the concept of Interim is a good idea.
