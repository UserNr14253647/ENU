# Raspberry Pi

In 2015 we purchased enough Raspberry Pi Model 2 boards to enable each tutor group to take away a board with the goal of doing something interesting with it. Here are some of the ideas for things that can be done:

* [InterimOS](http://interim.mntmn.com/)
* [Commodore 64 Pi](http://www.commodorepi.co.nr/)
